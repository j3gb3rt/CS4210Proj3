#ifndef VALUE_DATETIME_H_INCLUDED
#define VALUE_DATETIME_H_INCLUDED

void
test_value_datetime(void);

#endif
