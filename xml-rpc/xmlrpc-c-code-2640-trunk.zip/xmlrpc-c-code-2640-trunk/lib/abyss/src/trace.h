#ifndef TRACE_H_INCLUDED
#define TRACE_H_INCLUDED

void
TraceMsg(const char * const fmt, ...);

void
TraceExit(const char * const fmt, ...);

#endif

